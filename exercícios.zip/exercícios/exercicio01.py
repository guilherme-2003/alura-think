num1 = int(input("Digite o primeiro número: ")) #Recebe um parâmetro de número inteiro passado pelo usuário e o armazena na variável "num1"
num2 = int(input("Digite o segundo número: ")) #Recebe um parâmetro de número inteiro passado pelo usuário e o armazena na variável "num2"

soma = num1 + num2 #Soma os valores das variáveis "num1" e "num2" e armazena o resultado na variável soma

print(f'{num1} + {num2} = {soma}') #Mostra o resultado da soma no terminal para o usuário